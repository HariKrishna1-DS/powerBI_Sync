"""Durable numbered captures and task-level snapshot comparison."""
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

import pandas as pd

IGNORED = {'Sync Timestamp', 'Queue Age Hours', 'Time Since Arrival', 'Task Time in Queue'}
CHANGE_COLUMNS = ['Change', 'Task Key', 'Column', 'Previous Value', 'Latest Value']


class PreviewStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS previews (id INTEGER PRIMARY KEY AUTOINCREMENT, '
                       'created TEXT NOT NULL, source TEXT NOT NULL, columns_json TEXT NOT NULL, rows_json TEXT NOT NULL)')

    @contextmanager
    def connect(self):
        connection = sqlite3.connect(self.root / 'previews.sqlite', timeout=30)
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    def save(self, frame, source='DataTrace'):
        from datatrace_sync import export_to_excel_and_csv
        frame = frame.copy().fillna('')
        frame.columns = [str(c).strip() for c in frame.columns]
        if frame.empty or frame.columns.duplicated().any() or any(not c for c in frame.columns):
            raise ValueError('The file must contain data and unique, nonblank column names.')
        rows = json.loads(frame.to_json(orient='records', date_format='iso'))
        created = datetime.now(timezone.utc).isoformat()
        with self.connect() as db:
            cursor = db.execute('INSERT INTO previews(created,source,columns_json,rows_json) VALUES(?,?,?,?)',
                                (created, source, json.dumps(list(frame.columns)), json.dumps(rows)))
            number = cursor.lastrowid
            export_to_excel_and_csv(frame, self.root / f'preview{number}')
        return self.get(number)

    def list(self):
        with self.connect() as db:
            return [{'id': i, 'name': f'preview{i}', 'created': created, 'source': source,
                     'row_count': len(json.loads(rows))} for i, created, source, rows in
                    db.execute('SELECT id,created,source,rows_json FROM previews ORDER BY id DESC')]

    def get(self, number):
        with self.connect() as db:
            record = db.execute('SELECT created,source,columns_json,rows_json FROM previews WHERE id=?', (number,)).fetchone()
        if not record:
            raise KeyError('Preview not found.')
        return {'id': number, 'name': f'preview{number}', 'created': record[0], 'source': record[1],
                'columns': json.loads(record[2]), 'rows': json.loads(record[3])}

    def delete(self, number):
        with self.connect() as db:
            cursor = db.execute('DELETE FROM previews WHERE id=?', (number,))
        if not cursor.rowcount:
            raise KeyError('Preview not found.')
        for suffix in ('csv', 'xlsx'):
            (self.root / f'preview{number}.{suffix}').unlink(missing_ok=True)


def rows_after_last_order(previous, latest):
    column = 'Order Number'
    result = {'available': False, 'column': column, 'anchor_order': '', 'anchor_index': None,
              'count': 0, 'first_added_order': '', 'latest_added_order': '',
              'columns': latest['columns'], 'rows': [], 'message': ''}
    if column not in previous['columns'] or column not in latest['columns']:
        result['message'] = 'Order Number is required in both previews for last-order comparison.'
        return result

    date_col = next((c for c in ['Arrival Time', 'RequestArrivalTime', 'In-Time', 'Arrival Date', 'Date', 'Received Date']
                     if c in previous['columns'] and c in latest['columns']), None)

    anchor_order = ''
    anchor_dt = None

    if date_col:
        valid_previous = []
        for index, row in enumerate(previous['rows']):
            ord_val = text_value(row.get(column)).strip()
            if not ord_val:
                continue
            parsed_dt = pd.to_datetime(row.get(date_col), errors='coerce')
            if pd.notna(parsed_dt):
                valid_previous.append((parsed_dt, index, ord_val, row))
        if valid_previous:
            valid_previous.sort(key=lambda x: (x[0], x[1]))
            anchor_dt, _, anchor_order, _ = valid_previous[-1]

    if not anchor_order:
        anchor_order = next((text_value(row.get(column)).strip() for row in reversed(previous['rows'])
                             if text_value(row.get(column)).strip()), '')

    if not anchor_order:
        result['message'] = 'The previous preview has no Order Number to use as an anchor.'
        return result

    result['anchor_order'] = anchor_order

    if date_col and anchor_dt is not None:
        after_rows = []
        for index, row in enumerate(latest['rows']):
            parsed_dt = pd.to_datetime(row.get(date_col), errors='coerce')
            if pd.notna(parsed_dt) and parsed_dt > anchor_dt:
                after_rows.append((parsed_dt, index, row))
        after_rows.sort(key=lambda x: (x[0], x[1]))
        result['available'] = True
        result['rows'] = [x[2] for x in after_rows]
        result['count'] = len(result['rows'])
        if result['rows']:
            result['first_added_order'] = text_value(result['rows'][0].get(column)).strip()
            result['latest_added_order'] = text_value(result['rows'][-1].get(column)).strip()
        result['message'] = f'{result["count"]} orders found after {anchor_order} in {latest["name"]}.'
        return result

    matches = [index for index, row in enumerate(latest['rows'])
               if text_value(row.get(column)).strip().casefold() == anchor_order.casefold()]
    if not matches:
        result['message'] = f'Last order {anchor_order} from the previous preview was not found in the latest preview.'
        return result

    result['available'] = True
    result['anchor_index'] = matches[-1]
    result['rows'] = latest['rows'][matches[-1] + 1:]
    result['count'] = len(result['rows'])
    if result['rows']:
        result['first_added_order'] = text_value(result['rows'][0].get(column)).strip()
        result['latest_added_order'] = text_value(result['rows'][-1].get(column)).strip()
    result['message'] = f'{result["count"]} orders found after {anchor_order} in {latest["name"]}.'
    return result




def text_value(value):
    return '' if value is None else str(value)


def compare(previous, latest, keys=None, ignore=None):
    ignored = IGNORED if ignore is None else set(ignore)
    columns = [c for c in dict.fromkeys(previous['columns'] + latest['columns']) if c not in ignored]
    old, new = previous['rows'], latest['rows']

    def valid(candidate):
        if not candidate or any(c not in previous['columns'] or c not in latest['columns'] for c in candidate):
            return False
        for rows in (old, new):
            identities = [tuple(text_value(row.get(c)) for c in candidate) for row in rows]
            if any(not any(k) for k in identities) or len(set(identities)) != len(identities):
                return False
        return True

    if keys and not valid(keys):
        raise ValueError('Matching columns must form a unique, nonblank key in both previews. Select additional columns.')
    if not keys:
        keys = next((candidate for candidate in [['Order Number'], ['OPON'], ['Task ID'],
                    ['Arrival Time', 'Parcel ID', 'Task Name', 'Client', 'Product']] if valid(candidate)), [])
    changes = []
    counts = {'added': 0, 'removed': 0, 'modified': 0, 'unchanged': 0}
    record_columns = ['Comparison Status'] + list(dict.fromkeys(previous['columns'] + latest['columns']))
    matched_rows, unmatched_rows = [], []

    def comparison_row(status, row):
        return {'Comparison Status': status, **{column: text_value((row or {}).get(column))
                                                for column in record_columns[1:]}}

    if keys:
        def index(rows):
            return {tuple(text_value(row.get(c)) for c in keys): row for row in rows}
        before, after = index(old), index(new)
        for key in dict.fromkeys(list(before) + list(after)):
            a, b = before.get(key), after.get(key)
            label = ' | '.join(key)
            if a is None or b is None:
                kind = 'Added' if a is None else 'Removed'
                counts[kind.lower()] += 1
                changes.append({'Change': kind, 'Task Key': label, 'Column': '(entire row)',
                                'Previous Value': json.dumps(a, ensure_ascii=False) if a else '',
                                'Latest Value': json.dumps(b, ensure_ascii=False) if b else ''})
            else:
                changed = [c for c in columns if text_value(a.get(c)) != text_value(b.get(c))]
                counts['modified' if changed else 'unchanged'] += 1
                matched_rows.append(comparison_row('Matched - changed' if changed else 'Unchanged', b))
                for c in changed:
                    changes.append({'Change': 'Modified', 'Task Key': label, 'Column': c,
                                    'Previous Value': text_value(a.get(c)), 'Latest Value': text_value(b.get(c))})
            if a is None:
                unmatched_rows.append(comparison_row('Newly Added', b))
            elif b is None:
                unmatched_rows.append(comparison_row('Missing', a))
        method = 'Matched by ' + ', '.join(keys)
    else:
        def fingerprints(rows):
            return Counter(tuple(text_value(row.get(c)) for c in columns) for row in rows)
        before, after = fingerprints(old), fingerprints(new)
        counts['unchanged'] = sum((before & after).values())
        for values, frequency in (before & after).items():
            for _ in range(frequency):
                matched_rows.append(comparison_row('Unchanged', dict(zip(columns, values))))
        for kind, delta in [('Removed', before - after), ('Added', after - before)]:
            counts[kind.lower()] = sum(delta.values())
            for values, frequency in delta.items():
                for _ in range(frequency):
                    row = json.dumps(dict(zip(columns, values)), ensure_ascii=False)
                    changes.append({'Change': kind, 'Task Key': '(unmatched)', 'Column': '(entire row)',
                                    'Previous Value': row if kind == 'Removed' else '',
                                    'Latest Value': row if kind == 'Added' else ''})
                    unmatched_rows.append(comparison_row('Missing' if kind == 'Removed' else 'Newly Added',
                                                         dict(zip(columns, values))))
        method = 'No unique task key: exact-row comparison. Updates appear as removed and added rows.'
    record_counts = {'matched': counts['modified'] + counts['unchanged'],
                     'missing': counts['removed'], 'newly_added': counts['added'],
                     'unchanged': counts['unchanged']}
    return {'columns': CHANGE_COLUMNS, 'rows': changes, 'counts': counts, 'keys': keys, 'method': method,
            'record_columns': record_columns, 'matched_rows': matched_rows,
            'unmatched_rows': unmatched_rows, 'record_counts': record_counts,
            'ignored': sorted(ignored), 'previous': previous['name'], 'latest': latest['name'],
            'order_append': rows_after_last_order(previous, latest),
            'added_columns': [c for c in latest['columns'] if c not in previous['columns']],
            'removed_columns': [c for c in previous['columns'] if c not in latest['columns']]}
